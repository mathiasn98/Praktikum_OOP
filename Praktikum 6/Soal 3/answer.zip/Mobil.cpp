#include "Mobil.h"
#include <iostream>
using namespace std;

Mobil::Mobil(string _tahun,string _warna,string _merek,int _panjang,int _lebar,int _tinggi){
	tahun = _tahun;
	warna = _warna;
	merek = _merek;
	panjang = _panjang;
	lebar = _lebar;
	tinggi = _tinggi;
}
string Mobil::getTahun(){return tahun;}
string Mobil::getWarna(){return warna;}
string Mobil::getMerek(){return merek;}
int Mobil::getPanjang(){return panjang;}
int Mobil::getLebar(){return lebar;}
int Mobil::getTinggi(){return tinggi;}
void Mobil::setTahun(string _tahun){tahun = _tahun;}
void Mobil::setWarna(string _warna){warna = _warna;}
void Mobil::setMerek(string _merek){merek = _merek;}
void Mobil::setPanjang(int _panjang){panjang = _panjang;}
void Mobil::setLebar(int _lebar){lebar = _lebar;}
void Mobil::setTinggi(int _tinggi){tinggi = _tinggi;}
void Mobil::bunyikanKlakson(){cout<<"Telolet"<<endl;}
void Mobil::cetakJenisBahanBakar(){cout<<"Air"<<endl;}

MobilCepat::MobilCepat(string _tahun,string _warna,string _merek,int _panjang,int _lebar,int _tinggi,int _maxKecepatan) : Mobil::Mobil(_tahun,_warna,_merek,_panjang,_lebar,_tinggi){
	maxKecepatan = _maxKecepatan;
}
int MobilCepat::getMaxKecepatan(){
	return maxKecepatan;
}
void MobilCepat::setMaxKecepatan(int _maxKecepatan){
	maxKecepatan = _maxKecepatan;
}
void MobilCepat::bunyikanKlakson(){
	cout<<"Ngeng...din...din"<<endl;
}
void MobilCepat::cetakJenisBahanBakar(){
	cout<<"Avtur"<<endl;
}
