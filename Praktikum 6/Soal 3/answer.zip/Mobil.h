#include <iostream>
#include <string>
using namespace std;
#ifndef MOBIL_H
#define MOBIL_H

class Mobil{
	public:
		Mobil(string,string,string,int,int,int);
		string getTahun();
		string getWarna();
		string getMerek();
		int getPanjang();
		int getLebar();
		int getTinggi();
		void setTahun(string);
		void setWarna(string);
		void setMerek(string);
		void setPanjang(int);
		void setLebar(int);
		void setTinggi(int);
		virtual void bunyikanKlakson();
		virtual void cetakJenisBahanBakar();
	protected:
		string tahun,warna,merek;
		int panjang,lebar,tinggi;
};


class MobilCepat : public Mobil{
	public:
		MobilCepat(string,string,string,int,int,int,int);
		int getMaxKecepatan();
		void setMaxKecepatan(int);
		void bunyikanKlakson();
		void cetakJenisBahanBakar();
	private:
		int maxKecepatan;
};

#endif
