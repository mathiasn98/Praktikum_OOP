#include "RekeningGiro.h"

// Konstruktor menginisialisi saldo (parameter 1) dan suku bunga (parameter 2)
// Set suku bunga 0.0 apabila suku bunga bernilai negatif
RekeningGiro::RekeningGiro(double _saldo, double _sukuBunga):Rekening(_saldo){
	Rekening::setSaldo(_saldo);
	if(_sukuBunga < 0){
		sukuBunga = 0;
	}
	else{
		sukuBunga = _sukuBunga;
	}
}

// Getter, Setter
void RekeningGiro::setSukuBunga(double _sukuBunga){
	sukuBunga = _sukuBunga;
}
double RekeningGiro::getSukuBunga() const{
	return sukuBunga;
}

// Member Function
// Bunga dihitung dari saldo dikali suku bunga
double RekeningGiro::hitungBunga(){
	return Rekening::getSaldo()*sukuBunga;
}

