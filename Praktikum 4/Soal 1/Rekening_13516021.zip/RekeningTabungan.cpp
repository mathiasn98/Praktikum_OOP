#include "RekeningTabungan.h"
	// Konstruktor menginisialisi saldo (parameter 1) dan biaya transaksi (parameter 2)
	// Set biaya transaksi 0.0 apabila biaya transaksi bernilai negatif
	RekeningTabungan::RekeningTabungan(double _saldo, double _biayaTransaksi):Rekening(_saldo){
		Rekening::setSaldo(_saldo);
		biayaTransaksi = _biayaTransaksi;
	}

	// Getter, Setter
	void RekeningTabungan::setBiayaTransaksi(double _biayaTransaksi){
		biayaTransaksi = _biayaTransaksi;
	}
	double RekeningTabungan::getBiayaTransaksi() const{
		return biayaTransaksi;
	}
	
	// Member Function
	// Panggil fungsi simpanUang dari parent class
	// Kurangkan saldo dengan biaya transaksi
	void RekeningTabungan::simpanUang(double _uang){
		Rekening::simpanUang(_uang-biayaTransaksi);
	}

	// Panggil fungsi tarikUang dari parent class
	// Kurangkan saldo dengan biaya transaksi hanya jika penarikan uang berhasil
	// Saldo mungkin saja menjadi negatif apabila setelah penarikan, saldo < biaya transaksi
	// Kembalikan boolean yang mengindikasikan apakah uang berhasil ditarik atau tidak
	bool RekeningTabungan::tarikUang(double _tarik) {
		if(Rekening::getSaldo()< _tarik){
			return false;
		}
		else{
			double tempSaldo = Rekening::getSaldo();
			Rekening::setSaldo(tempSaldo-_tarik-biayaTransaksi);
			return true;
		}
	}

