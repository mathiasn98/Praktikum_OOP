#ifndef MAHASISWA_HPP
#define MAHASISWA_HPP
#include <iostream>
#include "Alamat.hpp"
using namespace std;

class Mahasiswa{
	public:
		Mahasiswa(string,string);
		Mahasiswa(string,string,Alamat);
		~Mahasiswa();
		
		Mahasiswa(const Mahasiswa&);
		string getNama();
		string getNim();
		Alamat getAlamat();
		void setNama(string);
		void setNim(string);
		void setAlamat(Alamat);
	private:
		string nama,nim;
		Alamat alamat;
};
#endif
