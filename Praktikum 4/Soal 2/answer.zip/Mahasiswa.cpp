
#include "Mahasiswa.hpp"

Mahasiswa::Mahasiswa(string _nama,string _nim){
	nama = _nama;
	nim = _nim;
}
Mahasiswa::Mahasiswa(string _nama,string _nim,Alamat _alamat){
	nama = _nama;
	nim = _nim;
	alamat = _alamat;
}
Mahasiswa::~Mahasiswa(){
}

Mahasiswa::Mahasiswa(const Mahasiswa& _mahasiswa){
	alamat = _mahasiswa.alamat;
	nama = _mahasiswa.nama;
	nim = _mahasiswa.nim;
}
string Mahasiswa::getNama(){
	return nama;
}
string Mahasiswa::getNim(){
	return nim;
}
Alamat Mahasiswa::getAlamat(){
	return alamat;
}
void Mahasiswa::setNama(string _nama){
	nama = _nama;
}
void Mahasiswa::setNim(string _nim){
	nim = _nim;
}
void Mahasiswa::setAlamat(Alamat _alamat){
	alamat = _alamat;
}
