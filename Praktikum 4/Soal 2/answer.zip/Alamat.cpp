#include "Alamat.hpp"
Alamat::Alamat(){
	provinsi = ' ';
	kota = ' ';
	jalan = ' ';
}
Alamat::Alamat(string _provinsi,string _kota,string _jalan){
	provinsi = _provinsi;
	kota = _kota;
	jalan = _jalan;
}
string Alamat::getProvinsi(){
	return provinsi;
}
string Alamat::getKota(){
	return kota;
}
string Alamat::getJalan(){
	return jalan;
}
void Alamat::setProvinsi(string _provinsi){
	provinsi = _provinsi;
}
void Alamat::setKota(string _kota){
	kota = _kota;
}
void Alamat::setJalan(string _jalan){
	jalan = _jalan;
}
string Alamat::getAlamatLengkap(){
	string alamatLengkap = "Jalan "+jalan+", "+kota+", "+provinsi+".";
	return alamatLengkap;
}


