#ifndef ALAMAT_HPP
#define ALAMAT_HPP
#include <iostream>
using namespace std;

class Alamat{

    public:
        Alamat();
        Alamat(string,string,string);
        string getProvinsi();
        string getKota();
        string getJalan();
        void setProvinsi(string);
        void setKota(string);
        void setJalan(string);
        string getAlamatLengkap();
        
    private:
        string provinsi, kota, jalan;
};
#endif
