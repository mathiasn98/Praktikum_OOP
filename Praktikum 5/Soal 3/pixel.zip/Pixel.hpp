#ifndef PIXEL_HPP
#define PIXEL_HPP
#include <iostream>
class Pixel {
    //hanya berisi method yang belum diimplementasi, pure virtual function
    virtual void preProcess() = 0;
    virtual void print() = 0;
};

#endif