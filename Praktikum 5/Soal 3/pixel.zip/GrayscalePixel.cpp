#include "GrayscalePixel.hpp"
#include <iostream>
using namespace std;
//ctor dengan parameter 3 buah integer (r, g, dan b dengan range nilai 0 <= x <= 255, wajib dicek)
//Apabila masukan > 255, kembalikan nilai mulai dari 0 lagi
//Contoh: 256 -> 0, 257 -> 1, dst
//Apabila masukan < 0, kembalikan nilai absolutnya tetap pertahankan range 0 <= x <= 255.
//Contoh: -12 -> 12, -257 -> 1

int convertNum(int x){
    if(x<0){
        return (-x)%256;
    }
    else{
        return x%256;
    }
}

GrayscalePixel::GrayscalePixel(int r,int g,int b) : Pixel::Pixel(){
    rgb = new int[3];
    rgb[0] = convertNum(r);
    rgb[1] = convertNum(g);
    rgb[2] = convertNum(b);
}
//cctor
GrayscalePixel::GrayscalePixel(const GrayscalePixel& GsP) : Pixel::Pixel(){
    rgb[0] = GsP.rgb[0];
    rgb[1] = GsP.rgb[1];
    rgb[2] = GsP.rgb[2];
}
//dtor
GrayscalePixel::~GrayscalePixel(){
    delete rgb;
}
//getter&setter (masukan setter TIDAK selalu valid)
int GrayscalePixel::getRed() const{return rgb[0];}
int GrayscalePixel::getGreen() const{return rgb[1];}
int GrayscalePixel::getBlue() const{return rgb[2];}
void GrayscalePixel::setRed(int r){rgb[0] = convertNum(r);}
void GrayscalePixel::setGreen(int g){rgb[1] = convertNum(g);}
void GrayscalePixel::setBlue(int b){rgb[2] = convertNum(b);}

//Implementasi preProcess (method untuk membuat pixel menjadi grayscale)
//Grayscale pixel adalah pixel yang memiliki nilai R, G, dan B = rata-rata RGB.
//NB: Lakukan pembulatan ke bawah.
void GrayscalePixel::preProcess(){
    int avg = (rgb[0]+rgb[1]+rgb[2])/3;
    rgb[0] = rgb[1] = rgb[2] = avg;
}
void GrayscalePixel::print(){
    cout<<"GRAYSCALE("<<rgb[0]<<','<<rgb[1]<<','<<rgb[2]<<")\n";
}
//Implementasi print (method untuk menampilkan pixel)
//format: GRAYSCALE(r,g,b) diakhiri endline
//contoh: GRAYSCALE(1,12,123)

