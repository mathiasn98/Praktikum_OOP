#include "PhysicException.hpp"
using namespace std;
PhysicException::PhysicException(string _msg){
	msg = _msg;
}
string PhysicException::getMsg(){
	return msg;
}
