#ifndef PHYSICEXCEPTION_HPP
#define PHYSICEXCEPTION_HPP
#include <iostream>
using namespace std;
class PhysicException{
	public:
		PhysicException(string _msg);
		string getMsg();
	private:
		string msg;
	
};
#endif
