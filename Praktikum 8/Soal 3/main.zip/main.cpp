#include <iostream>
#include "PhysicException.hpp"
#include "Physic.hpp"
using namespace std;
int main(){
	try{
		Physic P1(25,1);
		cout<<P1.constant()<<endl;
	}
	catch(PhysicException PE){
		cout<<PE.getMsg()<<endl;
	}
	try{
		Physic P2(16,1);
		cout<<P2.constant()<<endl;
	}
	catch(PhysicException PE){
		cout<<PE.getMsg()<<endl;
	}
	try{
		Physic P3(5,0);
		cout<<P3.constant()<<endl;
		
	}
	catch(PhysicException PE){
		cout<<PE.getMsg()<<endl;
	}
	try{
		Physic P4(2,0);
		cout<<P4.constant()<<endl;
	}
	catch(PhysicException PE){
		cout<<PE.getMsg()<<endl;
	}
	
}
